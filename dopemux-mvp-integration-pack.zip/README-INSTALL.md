# Dopemux-MVP Integration Pack

Extract this zip at the **root** of your repository (e.g., `/path/to/dopemux-mvp/`).

## Quick Start
```bash
# from repo root
unzip dopemux-mvp-integration-pack.zip
pip install pre-commit
pre-commit install
pre-commit run -a

# optional: local docs site if using MkDocs
pip install mkdocs-material
mkdocs serve
```

## What's Included
- `.claude/commands/` → Claude Code slash commands (MCP-aware) for RFC/ADR/docs flows.
- `scripts/` → helper CLIs (`rfc_new.py`, `rfc_promote.py`, `docs_frontmatter_guard.py`).
- `.pre-commit-config.yaml` + linter configs → enforce docs quality locally.
- `.github/workflows/docs.yml` → run the same checks in CI.
- `docs/templates/` → RFC & ADR templates.

Author: @hu3mann • Generated: 2025-09-21
