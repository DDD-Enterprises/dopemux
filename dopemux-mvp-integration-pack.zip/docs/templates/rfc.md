---
id: rfc-XXXX
title: <Title>
type: rfc
status: draft
author: @hu3mann
created: 2025-09-21
last_review: 2025-09-21
sunset: 2025-09-21
feature_id: <feature-id>
tags: []
---

## Problem

## Context

## Options
| Option | Pros | Cons |
|---|---|---|

## Proposed Direction

## Open Questions

## Risks

## Timeline

## Reviewers
