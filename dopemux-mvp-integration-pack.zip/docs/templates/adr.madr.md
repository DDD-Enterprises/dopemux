---
id: adr-XXXX
title: <Title>
type: adr
status: proposed
date: 2025-09-21
author: @hu3mann
derived_from: <rfc-id>
---

## Context

## Decision Drivers

## Considered Options

## Decision Outcome

## Consequences
