#!/usr/bin/env python3
import sys, os, datetime, io, yaml, re
REQUIRED = ["id","title","type","status","author","created","last_review"]
TODAY = datetime.date.today().isoformat()
DEFAULT_AUTHOR = "@hu3mann"
def parse_frontmatter(text):
    if text.startswith("---\n"):
        end = text.find("\n---\n", 4)
        if end != -1:
            return yaml.safe_load(text[4:end]) or {}, text[end+5:]
    return None, text
def guess_type(path):
    p = path.replace("\\","/")
    if "/90-adr/" in p: return "adr"
    if "/91-rfc/" in p: return "rfc"
    return "explanation"
def ensure(path, fix=False):
    with open(path,"r",encoding="utf-8") as f: t=f.read()
    data, body = parse_frontmatter(t); changed=False
    if data is None:
        data = {"id": os.path.splitext(os.path.basename(path))[0],
                "title": os.path.basename(path).replace("-"," ").title(),
                "type": guess_type(path), "status": "draft",
                "author": DEFAULT_AUTHOR, "created": TODAY, "last_review": TODAY}
        changed=True
    else:
        for k in REQUIRED:
            if k not in data: data[k] = {"status":"draft","author":DEFAULT_AUTHOR,
                                         "created":TODAY,"last_review":TODAY}.get(k, data.get(k)); changed=True
    if changed and fix:
        buf=io.StringIO(); yaml.safe_dump(data, buf, sort_keys=False)
        with open(path,"w",encoding="utf-8") as f: f.write(f"---\n{buf.getvalue()}---\n{body.lstrip()}")
    return changed
if __name__=="__main__":
    modified=[]
    for root,_,files in os.walk("docs"):
        for fn in files:
            if fn.endswith(".md"):
                p=os.path.join(root,fn)
                if ensure(p, fix="--fix" in sys.argv): modified.append(p)
    print(f"Updated {len(modified)} files" if modified else "All good.")
    sys.exit(0 if "--fix" in sys.argv else (1 if modified else 0))
