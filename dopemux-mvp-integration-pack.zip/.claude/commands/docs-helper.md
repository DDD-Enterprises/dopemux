# /docs-helper
Show a one-pager refresher:
- Diátaxis shelves & when to write each
- RFC → ADR → arc42 flow
- Commands to run next (`/rfc:new`, `/rfc:lint`, `/rfc:promote`)
- Common mistakes & quick fixes
Attach: RFC/ADR templates from `docs/templates/` when available.
