# /adr:new
Create a new MADR-style ADR.

Usage: `/adr:new "Title"`
Steps:
1) Compute next ADR number; create `docs/90-adr/ADR-####-YYYY-MM-DD-<slug>.md`.
2) Include sections: Context, Decision Drivers, Considered Options, Decision Outcome, Consequences.
3) If derived from an RFC, set `derived_from:` in front-matter.
