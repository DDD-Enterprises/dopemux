---
id: c4-readme
title: C4 Diagrams
type: reference
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

Place your C4 PNG/SVG files here:
- c4-l0-context.png
- c4-l1-container.png
- c4-l2-component.png
- c4-l3-code.png
