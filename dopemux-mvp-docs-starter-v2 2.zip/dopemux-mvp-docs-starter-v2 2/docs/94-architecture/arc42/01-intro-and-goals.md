---
id: arc42-01-intro
title: arc42 — 01. Introduction & Goals
type: explanation
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

Project goals, quality goals, stakeholders.
