---
id: ref-docs-structure
title: Docs structure, naming, and front-matter
type: reference
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

**Folders**
```
docs/
  01-tutorials/
  02-how-to/
  03-reference/
  04-explanation/
  90-adr/
  91-rfc/
  92-runbooks/
  94-architecture/
    c4/
    arc42/
  _manifest.yaml
  _glossary.md
```
**Naming**
- ADR: `ADR-####-YYYY-MM-DD-title.md`
- C4: `c4-l0-context.png`, `c4-l1-container.png`, `c4-l2-component.png`, `c4-l3-code.png`
- How-to: `how-to-verb-object.md`
- Runbook: `runbook-<service>-<scenario>.md`
