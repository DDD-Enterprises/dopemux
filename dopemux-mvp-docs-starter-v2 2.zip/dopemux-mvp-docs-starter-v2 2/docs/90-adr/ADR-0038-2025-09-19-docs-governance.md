---
id: adr-0038
title: Adopt Diátaxis + ADRs + Feature Hubs + MCP Context Pull
type: adr
status: approved
date: 2025-09-19
feature_id: feat-docs-governance
deciders: [@hu3mann]
---

## Context
We generate many documents; retrieval is inconsistent and decisions are buried in chats.

## Decision
Use Diátaxis shelves, MADR-style ADRs for decisions, one **Feature Hub** per feature, and implement `/doc:pull` via MCP to always load the right context.

## Consequences
- Docs predictable & searchable (MkDocs Material).
- Cross-links via `feature_id` and `_manifest.yaml`.
- PRs enforce freshness (`owner` + `next_review`).
