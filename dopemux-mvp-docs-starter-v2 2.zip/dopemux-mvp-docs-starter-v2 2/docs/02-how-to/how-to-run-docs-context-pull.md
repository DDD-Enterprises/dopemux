---
id: howto-context-pull
title: How to run a docs context pull in Claude Code
type: how-to
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
feature_id: feat-docs-governance
---

1) In Claude Code, type: `/doc:pull "<ticket or file path>"`.
2) Review the Context Header (6–10 items), then proceed.
3) If an ADR is missing, run `/adr:new "<title>"` and link it here.
4) Commit with Conventional Commits and update `CHANGELOG.md`.
