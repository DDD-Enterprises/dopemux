---
id: howto-write-howto
title: How to write a great How-to
type: how-to
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

- Use an imperative title: `how-to-verb-object.md` (e.g., `how-to-rotate-keys.md`).
- Keep it task-focused; 5–12 steps max.
- Link to Reference for API details; link to ADR for decisions.
- Add `owner`, `last_review`, `next_review` to front-matter.
