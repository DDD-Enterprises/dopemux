---
id: research-2025-09-19
title: Raw brainstorm — docs governance
type: research
owner: @hu3mann
ttl: 30d
created: 2025-09-19
---

Bullet notes, links, interviews. After TTL, archive automatically.
