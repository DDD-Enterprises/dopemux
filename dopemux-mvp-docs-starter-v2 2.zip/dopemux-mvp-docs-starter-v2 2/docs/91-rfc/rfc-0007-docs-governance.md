---
id: rfc-0007
title: Governance for Docs + MCP Context Pull
type: rfc
status: draft
sunset: 2025-10-19
feature_id: feat-docs-governance
owner: @hu3mann
links:
  evidence: [explanation-context-pull-mcp]
---

## Problem
Doc overload, inconsistent retrieval, missed context during implementation.

## Proposal
Adopt Diátaxis + ADRs + Feature Hubs + `/doc:pull` (MCP) as a standard.

## Acceptance Criteria
- PRs fail if docs lack `owner` or `next_review`.
- `/doc:pull "<task>"` prints a 6–10 item context header + attaches files.
