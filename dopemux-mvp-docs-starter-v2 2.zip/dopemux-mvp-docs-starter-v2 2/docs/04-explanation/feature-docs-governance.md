---
id: feat-docs-governance
title: Feature Hub — Docs Governance & Context Pull
type: explanation
owner: @hu3mann
status: active
last_review: 2025-09-19
next_review: 2025-12-18
tags: [docs, governance, mcp, claude-code]
links:
  rfcs: [rfc-0007]
  adrs: [ADR-0038-2025-09-19-docs-governance]
  howtos: [how-to-run-docs-context-pull]
  reference: [docs-structure-and-naming]
---

This hub tracks the cross-feature workflow for brainstorming → design → implementation → shipping → operate.
It anchors the “context pull” pattern via MCP servers.
