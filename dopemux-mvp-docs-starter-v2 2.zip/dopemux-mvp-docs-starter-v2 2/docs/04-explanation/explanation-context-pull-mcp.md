---
id: explanation-context-pull-mcp
title: How the MCP-powered context pull works
type: explanation
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

`/doc:pull "<query>"` fans out to MCP servers (semantic search, ADR lookup, symbol docs, preferences), dedupes results, and prints a 6–10 item Context Header.
