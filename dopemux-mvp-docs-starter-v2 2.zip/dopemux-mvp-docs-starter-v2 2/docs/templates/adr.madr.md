---
id: adr-XXXX
title: <TITLE>
type: adr
status: proposed
date: 2025-09-19
owner: @hu3mann
---

## Context
<Why are we making this decision?>

## Decision
<The decision we are taking>

## Consequences
<Positive, negative, risks, follow-ups>
