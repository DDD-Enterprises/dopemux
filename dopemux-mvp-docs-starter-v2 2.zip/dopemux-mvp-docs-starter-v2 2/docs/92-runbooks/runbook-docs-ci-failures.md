---
id: runbook-docs-ci-failures
title: Runbook — Fix docs CI failures
type: runbook
owner: @hu3mann
last_review: 2025-09-19
next_review: 2025-12-18
---

**Symptoms**: CI failed on docs.

**Checks**
- Missing front-matter? `pre-commit run -a`.
- Broken links? `lychee docs/**/*.md`.
- Past-due `next_review`? Update or archive.

**Rollback**: Revert offending commit; re-run checks.
